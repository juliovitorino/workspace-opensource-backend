package br.com.jcv.reminder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReminderApplicationTests {

	@Test
	void contextLoads() {
	}

}
