package br.com.jcv.reaction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactionApplicationTests {

	@Test
	void contextLoads() {
	}

}
